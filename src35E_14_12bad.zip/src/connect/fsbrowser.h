/*
 * fsbrowser.h
 * Created: 30.11.2018
 * Author: OLMORO
 */ 

#ifndef _FSBROWSER_H_
#define _FSBROWSER_H_

void initFSBrowser();

void runFSBrowser( float _voltage, float _current, float _celsius, float _ahCharge, int _fanPwm );

#endif